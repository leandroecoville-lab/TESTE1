# Troubleshooting (padrão)

## Sintomas comuns
- Falha ao subir compose
- Testes quebrando
- Erro de contrato/evento

## Correção padrão
- Gerar OCA-REPORT (se só diagnóstico) ou OCA-PATCH (se alterar código)
- Executar merge + testes + docs
