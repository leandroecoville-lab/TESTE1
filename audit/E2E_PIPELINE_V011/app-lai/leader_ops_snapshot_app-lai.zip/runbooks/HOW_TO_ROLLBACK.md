# HOW_TO_ROLLBACK — app-lai

Placeholder (Pack0). Defina rollback no Pack1.
