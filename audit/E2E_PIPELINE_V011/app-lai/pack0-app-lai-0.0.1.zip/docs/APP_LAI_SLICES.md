# APP_LAI_SLICES — App LAI (thin-slices / PEC)

Este documento define *thin-slices* para o **App LAI** como hub operacional:
feed governado, rotinas e superfícies de decisão.

## Objetivo
- Consolidar eventos do ecossistema em um feed governado (`lai.app.feed.item.created`)
- Entregar UX simples (cockpit) com clareza de próximos passos e trilhas
- Integrar com GPT corporativo (RAG) de forma auditável e com minimização

## Thin-slices (PEC)
- PEC1.01 — Feed ingest (Event Bus → Feed) + dedupe + permissão por papel
- PEC1.02 — Feed read API + paginação + filtros por tenant/time
- PEC1.03 — Notificações (push/email) via canais oficiais + preferências
- PEC1.04 — GPT interno: consulta RAG + citações + policy guardrails
- PEC1.05 — Painel Master (governança): métricas e trilhas (sem exposição indevida)

## Contratos mínimos
- `lai.app.feed.item.created.v1`
- `lai.app.notification.requested.v1`

## Segurança operacional
- Privacidade por design, minimização e opt-out
- Auditoria append-only para ações administrativas
