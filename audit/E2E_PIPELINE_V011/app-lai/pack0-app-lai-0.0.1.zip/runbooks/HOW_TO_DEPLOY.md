# HOW_TO_DEPLOY — app-lai

Placeholder (Pack0). Defina deploy no Pack1.
