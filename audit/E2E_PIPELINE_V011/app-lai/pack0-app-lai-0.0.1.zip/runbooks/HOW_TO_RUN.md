# HOW_TO_RUN — app-lai (Pack0)

Este é um Pack0 de planejamento. Ele não sobe o serviço final.
Próximo passo: gerar Pack1 (app-lai) com código executável.
