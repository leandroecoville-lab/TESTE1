# Prompt de Continuidade (Pack0 — culture-people)

Este arquivo existe para re-hidratar o GPT Builder sem depender de memória entre chats.

## Padrões imutáveis
- Pack-first: toda entrega é RELEASE PACK.
- DoD por pack: run + test + docs + manifest + audit.
- Sem camuflagem/execução velada/obfuscação de logs.

## Cadeia de packs
- Atual: pack0-culture-people@0.0.1

## Próximo pack esperado
- pack1-culture-people@1.0.0 (thin-slice executável)
