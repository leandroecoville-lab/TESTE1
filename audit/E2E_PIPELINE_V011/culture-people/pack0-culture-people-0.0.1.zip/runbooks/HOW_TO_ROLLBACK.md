# HOW_TO_ROLLBACK — culture-people

Placeholder (Pack0). Defina rollback no Pack1.
