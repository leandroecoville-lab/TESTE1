# HOW_TO_RUN — culture-people (Pack0)

Este é um Pack0 de planejamento. Ele não sobe o serviço final.
Próximo passo: gerar Pack1 (culture-people) com código executável.
