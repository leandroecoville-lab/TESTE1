# 300 Franchising, a maior do mundo e nossa missão

Pack0 (Planejamento) — módulo: culture-people
