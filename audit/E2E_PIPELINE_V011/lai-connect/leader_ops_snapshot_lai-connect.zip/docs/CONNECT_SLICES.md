# CONNECT_SLICES — LAI Connect (thin-slices / PEC)

Este documento define *thin-slices* para o módulo **LAI Connect** (SaaS omnichannel),
com foco em **APIs oficiais**, **opt-in**, **auditoria** e **não perda semântica** (eventos ricos).

## Objetivo
- Capturar mensagens inbound (ex.: WhatsApp via API oficial) sem perda de contexto
- Normalizar em eventos **CloudEvents** canônicos (`lai.connect.message.received`)
- Executar roteamento por regras governadas (state machine) e produzir outbound (`...message.sent`)
- Registrar auditoria append-only (`trace_id`, `tenant_id`, `actor_id`, `channel`, `consent_ref`)

## Thin-slices (PEC)
- PEC1.01 — Inbound Message → Event Bus (CloudEvents) + Idempotência
- PEC1.02 — Identity resolution (tenant-safe) + RBAC/TBAC (mínimo)
- PEC1.03 — Decision Router (regras + handoff) + Audit trail
- PEC1.04 — Outbound Sender (API oficial) + rate limits + retries
- PEC1.05 — Observabilidade: logs/métricas/traces + SLO inicial + alertas básicos

## Contratos mínimos
- `lai.connect.message.received.v1`
- `lai.connect.message.sent.v1`

## Segurança operacional
- Zero-trust + segregação por tenant
- Opt-in obrigatório para mensagens proativas
- Sem scraping / sem bypass / sem "simular humano" (somente APIs oficiais)
