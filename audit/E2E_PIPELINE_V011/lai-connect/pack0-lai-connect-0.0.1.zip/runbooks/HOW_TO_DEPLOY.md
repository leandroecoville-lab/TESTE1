# HOW_TO_DEPLOY — lai-connect

Placeholder (Pack0). Defina deploy no Pack1.
