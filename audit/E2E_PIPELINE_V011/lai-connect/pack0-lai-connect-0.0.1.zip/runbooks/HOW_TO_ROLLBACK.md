# HOW_TO_ROLLBACK — lai-connect

Placeholder (Pack0). Defina rollback no Pack1.
