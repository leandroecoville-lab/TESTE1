# HOW_TO_RUN — lai-connect (Pack0)

Este é um Pack0 de planejamento. Ele não sobe o serviço final.
Próximo passo: gerar Pack1 (lai-connect) com código executável.
