# HOW_TO_DEPLOY — meetcore

Placeholder (Pack0). Defina deploy no Pack1.
