# PERFORMANCE_BUDGETS — MeetCore (SLO/SLI iniciais)

Este documento define budgets mínimos para evitar regressão e guiar decisões de arquitetura.

## Latência (targets iniciais)
- Streaming (p95): <= 300ms
- Insights (p95): <= 1s
- Transcrição parcial (p95): <= 2s

## Escala (targets iniciais)
- MVP: 50 calls simultâneas
- Fase 2: 200 calls simultâneas (com workers paralelos)

## Observabilidade mínima
- Logs estruturados + trace_id
- Métricas de jitter/packet loss e queue lag (pós-call)
