# MEETCORE_SLICES — MeetCore-first slicing (PEC Chain)

Este documento é um artefato explícito para evitar drift e manter o MeetCore evoluindo em fatias executáveis.

## Visão
MeetCore é o módulo de maior complexidade operacional (tempo real / mídia / pós-call). Para manter previsibilidade, o módulo deve nascer fatiado.

## Slices recomendados (PEC1.01 → PEC1.05)
- PEC1.01 — Signaling + Rooms + Tokens + eventos `meetcore.call.started`/`meetcore.call.ended`
- PEC1.02 — Media pipeline (SFU) + ICE/TURN + /health + métricas básicas
- PEC1.03 — Recorder + Storage (política de retenção) + transcrição (stub→real)
- PEC1.04 — Real-time Insight Bus (janelas de áudio/texto) + Cockpit minimal (timeline)
- PEC1.05 — Post-call worker + relatório derivado + atualização de CRM simbólico

## Regra de progressão
- Cada PEC só é promovida via `merge --mode promoted` (evidência dentro do snapshot).
- O Pack1 do MeetCore deve começar pelo PEC1.01 (thin-slice).
