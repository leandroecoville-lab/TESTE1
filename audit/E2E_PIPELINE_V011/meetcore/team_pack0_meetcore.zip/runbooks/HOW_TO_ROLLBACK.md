# HOW_TO_ROLLBACK — meetcore

Placeholder (Pack0). Defina rollback no Pack1.
