# HOW_TO_RUN — meetcore (Pack0)

Este é um Pack0 de planejamento. Ele não sobe o serviço final.
Próximo passo: gerar Pack1 (meetcore) com código executável.
